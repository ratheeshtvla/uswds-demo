import Component from "./usa-checklist.twig";

export default {
  title: "Components/Form Inputs/Checklist",
};

const Template = (args) => Component(args);

export const Checklist = Template.bind({});
