import Component from "./usa-prose.twig";

export default {
  title: "Components/Prose",
};

const Template = (args) => Component(args);

export const Default = Template.bind({});
